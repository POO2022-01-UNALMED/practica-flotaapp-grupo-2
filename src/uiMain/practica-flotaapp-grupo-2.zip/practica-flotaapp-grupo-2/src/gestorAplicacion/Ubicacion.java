/*
 * Clase con los enumeradores de ubicaci�n de silla
 * Estructuras: enum
 * 
 * @author: Mateo Hechavarria, Juan Pablo Pineda, Miguel Angel Fonseca, Haison Urrutia
 */


package gestorAplicacion;

public enum Ubicacion {
    VENTANA, PASILLO, INTERMEDIO
}
