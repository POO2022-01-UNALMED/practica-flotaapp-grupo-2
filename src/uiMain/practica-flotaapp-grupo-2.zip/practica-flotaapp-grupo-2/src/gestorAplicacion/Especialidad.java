/*
 * Clase con los enumeradores de cada una de las especialidades para el Especialista
 * Estructuras: enum
 * 
 * @author: Mateo Hechavarria, Juan Pablo Pineda, Miguel Angel Fonseca, Haison Urrutia
 */



package gestorAplicacion;

public enum Especialidad {
    ELECTRICO, MECANICO , SILLETERIA, ADMINISTRADOR
}
