/*
 * Clase con los enumeradores de categoria del pase del conductor conductor
 * Estructuras enum
 * 
 * @author: Mateo Hechavarria, Juan Pablo Pineda, Miguel Angel Fonseca, Haison Urrutia
 */


package gestorAplicacion;

public enum Categoria {
    B2, B3, C1, C2, C3
}
