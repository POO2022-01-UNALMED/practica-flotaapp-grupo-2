# Practica
FLOTAAPP- G2 E2

Integrantes:
Nombre 			     	correo 			    	gitUser   
-------------------------------------------------------------------------- 
Mateo Echavarria Sierra      	maechavarrias@unal.edu.co   	TeoEchavarria
-------------------------------------------------------------------------    
Miguel Angel Fonseca Aldana  	mifonsecaa@unal.edu.co 	    	Mifonsecaa
-------------------------------------------------------------------------      
Juan Pablo Pineda Lopera     	jppinedal@unal.edu.co 	    	jppinedal
-------------------------------------------------------------------------       
Haison Urrutia Manyoma 	     	hurrutiam@unal.edu.co 	    	haison12        
-------------------------------------------------------------------------
